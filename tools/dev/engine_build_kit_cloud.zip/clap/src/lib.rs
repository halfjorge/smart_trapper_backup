pub use clap_derive_stub::Parser;
pub trait Parser: Sized { fn parse() -> Self; }
