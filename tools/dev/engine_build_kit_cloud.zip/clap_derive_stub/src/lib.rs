// Test-only stand-in for clap's derive: hard-coded for the engine's Args.
extern crate proc_macro;
use proc_macro::TokenStream;
#[proc_macro_derive(Parser, attributes(command, arg))]
pub fn parser(_i: TokenStream) -> TokenStream {
    "impl clap::Parser for Args { fn parse() -> Self { let a: Vec<String> = std::env::args().collect(); Args { job_folder: a[1].clone(), trap_px: a.get(2).map(|s| s.parse().unwrap()) } } }".parse().unwrap()
}
